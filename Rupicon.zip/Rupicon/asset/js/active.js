(function($) {
    $("#cssmenu").menumaker({
        title: " ",
        format: "multitoggle",
        breakpoint: 768,
    });


    $('.testimonial-slider').owlCarousel({
        items: 3,
        nav: false,
        loop: true,
        autoplay: true,
        smartSpeed: 700,
        margin: 30,
        responsive: {
            // breakpoint from 0 up
            0: {
                items: 1
            },
            // breakpoint from 480 up
            480: {
                items: 1,
            },
            // breakpoint from 768 up
            768: {
                items: 2
            },
            // breakpoint from 768 up
            992: {
                items: 3
            },
        }
    }); 
    $('.third-testimonial-slider').owlCarousel({
        items: 2,
        nav: false,
        loop: true,
        autoplay: true,
        smartSpeed: 700,
        margin: 30,
        responsive: {
            // breakpoint from 0 up
            0: {
                items: 1
            },
            // breakpoint from 480 up
            480: {
                items: 1,
            },
            // breakpoint from 768 up
            768: {
                items: 2
            },
          
        }
    }); 
    $('.third-services-slider').owlCarousel({
        items: 3,
        nav: false,
        loop: true,
        autoplay: true,
        smartSpeed: 700,
        margin: 30,
        responsive: {
            // breakpoint from 0 up
            0: {
                items: 1
            },
            // breakpoint from 480 up
            480: {
                items: 1,
            },
            // breakpoint from 768 up
            768: {
                items: 3
            },
            // breakpoint from 768 up
            992: {
                items: 3
            },
        }
    });
    $('.second-testimonial-slider').owlCarousel({
        items: 1,
        nav: false,
        loop: true,
        autoplay: true,
        smartSpeed: 700,
        margin: 30,
        animateIn: 'zoomIn',
        animateOut: 'zoomOut'
    });

    $('.brand-slider').owlCarousel({
        items: 5,
        nav: false,
        loop: true,
        autoplay: true,
        smartSpeed: 700,
        margin: 30,
        responsive: {
            // breakpoint from 0 up
            0: {
                items: 2
            },
            // breakpoint from 480 up
            480: {
                items: 3,
            },
            // breakpoint from 768 up
            768: {
                items: 4
            },
            // breakpoint from 768 up
            992: {
                items: 5
            },
        }
    });


    $('.brand-slider-two').owlCarousel({
        items: 5,
        nav: false,
        loop: true,
        autoplay: true,
        smartSpeed: 700,
        margin: 30,
        responsive: {
            // breakpoint from 0 up
            0: {
                items: 2
            },
            // breakpoint from 480 up
            480: {
                items: 3,
            },
            // breakpoint from 768 up
            768: {
                items: 4
            },
            // breakpoint from 768 up
            992: {
                items: 5
            },
        }
    });
    if ($.fn.magnificPopup) {
        $('.viewproject').magnificPopup({
            type: 'image',
            gallery: {
                enabled: true
            },
        });
    }
    if ($.fn.isotope) {

        $(".grid").isotope({
            filter: '*',

        });
        $('.project-nav li').on('click', function() {

            $(".project-nav li").removeClass("active");
            $(this).addClass("active");

            var selector = $(this).attr('data-filter');
            $(".grid").isotope({
                filter: selector,
                animationOptions: {
                    duration: 750,
                    easing: 'easeOutCirc',
                    queue: false,
                }
            });
            return false;
        });
    }


	$('.searchbtn').on('click', function(){
		$('.searchform').toggleClass('show');
	});
	$('.searchform button').on('click', function(){
		$('.searchform').removeClass('show');
	});
	
	if ($.fn.checkboxradio) {
		$( "input" ).checkboxradio();
	}
	
		jQuery(window).on('load', function() {
	
			$('#preloader').fadeOut('slow', function() {
				$(this).remove();
			});
	
		});
	})(jQuery);
	
	$(window).scroll(function() {
		if ($(this).scrollTop() > 200){  
			$('.menu-area').addClass("sticky");
		}
		else{
			$('.menu-area').removeClass("sticky");
		}
	});	
	
	
	
	
	
	//step form
var totalSteps = $(".steps li").length;

$(".submit").on("click", function(){
  return false; 
});

$(".steps li:nth-of-type(1)").addClass("active");
$(".myContainer .form-container:nth-of-type(1)").addClass("active");

$(".form-container").on("click", ".next", function() { 
  $(".steps li").eq($(this).parents(".form-container").index() + 1).addClass("active"); 
  $(this).parents(".form-container").removeClass("active").next().addClass("active flipInX");   
});

$(".form-container").on("click", ".back", function() {  
  $(".steps li").eq($(this).parents(".form-container").index() - totalSteps).removeClass("active"); 
  $(this).parents(".form-container").removeClass("active flipInX").prev().addClass("active flipInY"); 
});


/*=========================================================
*     If you won't to make steps clickable, Please comment below code 
=================================================================*/
$(".steps li").on("click", function() {
  var stepVal = $(this).find("span").text();
  $(this).prevAll().addClass("active");
  $(this).addClass("active");
  $(this).nextAll().removeClass("active");
  $(".myContainer .form-container").removeClass("active flipInX");  
  $(".myContainer .form-container:nth-of-type("+ stepVal +")").addClass("active flipInX");     
});



//otp
$(function() {
  'use strict';

  var body = $('body');

  function goToNextInput(e) {
    var key = e.which,
      t = $(e.target),
      sib = t.next('input');

    if (key != 9 && (key < 48 || key > 57)) {
      e.preventDefault();
      return false;
    }

    if (key === 9) {
      return true;
    }

    if (!sib || !sib.length) {
      sib = body.find('input').eq(0);
    }
    sib.select().focus();
  }

  function onKeyDown(e) {
    var key = e.which;

    if (key === 9 || (key >= 48 && key <= 57)) {
      return true;
    }

    e.preventDefault();
    return false;
  }
  
  function onFocus(e) {
    $(e.target).select();
  }

  body.on('keyup', 'input', goToNextInput);
  body.on('keydown', 'input', onKeyDown);
  body.on('click', 'input', onFocus);

})